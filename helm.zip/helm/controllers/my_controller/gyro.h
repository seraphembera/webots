#ifndef __GYRO_H
#define __GYRO_H

void gyro_init(void);
double gyro_yaw_data_update(void);

#endif
